# Einzelne Einheiten

Informationen zu einzelnen Einheiten.

- Il2 Flugzeuge haben gute panzerung
  - "Ilyushin Il-2"
- Gyrdia DP gut auf großer Reichweite, Gyrdia auf kleine Distanz (auch wegen Anti-Tank)
- T34/76 dient als Infanterieunterstützung --> gegen Stug4 vermeiden (Penetration von T34 < Panzerung von Stug)
- M3 besser als M2
- SG42 (Sturmgewehr?) in Häuser
- 37 mm anti air gun ist ein gutes Standardmodell
- [ZiS 2 (57 mm APK)](https://en.wikipedia.org/wiki/57_mm_anti-tank_gun_M1943_(ZiS-2)) gegen Panzer (duh?)
  - "Zavod imeni Stalina"
- [IS2 (Komroti)](https://de.wikipedia.org/wiki/IS-2_(Panzer)) auf freies Feld
  - "Iossif Stalin"
  - Nachfolger von IS1
