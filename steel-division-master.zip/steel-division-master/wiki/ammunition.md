# Munition

- HE shell: soft targets like infantry
- AP shell: hard targets
