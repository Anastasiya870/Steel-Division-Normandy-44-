# Abkürzungen

| Name | Beschreibung |
| :-: | :-- |
| AP | Armor piercing |
| APC | Armor piercing, capped |
| APCR | Armor piercing, Composite Rigid |
| HE | High explosive |
| HEAT | High Explosive Anti Tank |
| MLRS | Multiple Launch Rocket System |
| SP | Self-propelled (eigener Motorantrieb) |
| APK | Anti-Panzer-Kanone |
